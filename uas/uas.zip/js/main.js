//=========== show menu ======== *//
const showmenu32